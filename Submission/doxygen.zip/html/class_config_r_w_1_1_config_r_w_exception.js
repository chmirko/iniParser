var class_config_r_w_1_1_config_r_w_exception =
[
    [ "ConfigRWException", "class_config_r_w_1_1_config_r_w_exception.html#abb655bd4845b21ec3316826501b0bc62", null ],
    [ "LogMsg", "class_config_r_w_1_1_config_r_w_exception.html#aca905fb9c956016d6a8afdd8763a3145", null ],
    [ "UserMsg", "class_config_r_w_1_1_config_r_w_exception.html#ab91a854bad1de900f7d2c4c66d7e77ff", null ]
];