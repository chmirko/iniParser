var interface_usage_examples_1_1_players =
[
    [ "Player1", "interface_usage_examples_1_1_players.html#aeed79cda57249298ad963065cd48a7ce", null ],
    [ "Player2", "interface_usage_examples_1_1_players.html#aae197e79747f3d795e1206747117154b", null ]
];