var class_config_r_w_1_1_i_d_validation_exception =
[
    [ "IDValidationException", "class_config_r_w_1_1_i_d_validation_exception.html#ae2d3890022eac45d4478c07ad6886ac6", null ],
    [ "ValidatedID", "class_config_r_w_1_1_i_d_validation_exception.html#a95a066a800f2d0355e3a8e2d63eebec3", null ],
    [ "ValidatedProperty", "class_config_r_w_1_1_i_d_validation_exception.html#a9000672b241d15afa7c0a4e2330eaad6", null ]
];