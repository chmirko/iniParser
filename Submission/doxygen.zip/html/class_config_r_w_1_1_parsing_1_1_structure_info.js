var class_config_r_w_1_1_parsing_1_1_structure_info =
[
    [ "StructureInfo", "class_config_r_w_1_1_parsing_1_1_structure_info.html#a22c046a481ff0e17da3c542abd271aba", null ],
    [ "DescribingType", "class_config_r_w_1_1_parsing_1_1_structure_info.html#a7bcacc0aa151faf399c0a88aad4e4f6a", null ],
    [ "Sections", "class_config_r_w_1_1_parsing_1_1_structure_info.html#a4d762192b5ccc2904f7b4ad968ca6f3d", null ]
];