var interface_usage_examples_1_1_section1 =
[
    [ "number", "interface_usage_examples_1_1_section1.html#ab004cba9a5536141835199596dd9c08b", null ],
    [ "settableNumber", "interface_usage_examples_1_1_section1.html#a2aac4a678a25eb57a110dc4041a77a5e", null ]
];