var class_config_r_w_1_1_parsing_1_1_int32_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_int32_converter.html#a110abf18da188a555bbe92ff9c0cb849", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_int32_converter.html#a2f9475ea9307a51c4ade6752d022e218", null ]
];