var class_config_r_w_1_1_option_info_attribute =
[
    [ "OptionInfoAttribute", "class_config_r_w_1_1_option_info_attribute.html#a8cfb105d0a2aa45c15358679be56c1fb", null ],
    [ "DefaultValue", "class_config_r_w_1_1_option_info_attribute.html#ab0771da7fb5be788654f61dab58b201c", null ],
    [ "ID", "class_config_r_w_1_1_option_info_attribute.html#adc9a8a972c820809a4c681f429242497", null ],
    [ "IsOptional", "class_config_r_w_1_1_option_info_attribute.html#a28f099192b19a33b7452c08cfa0441be", null ]
];