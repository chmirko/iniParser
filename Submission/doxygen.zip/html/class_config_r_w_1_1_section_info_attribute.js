var class_config_r_w_1_1_section_info_attribute =
[
    [ "SectionInfoAttribute", "class_config_r_w_1_1_section_info_attribute.html#aa3844aea15dbc3c881047e2be5382bd1", null ],
    [ "ID", "class_config_r_w_1_1_section_info_attribute.html#af54d01b2077eeaf241f061157e65feb5", null ],
    [ "IsOptional", "class_config_r_w_1_1_section_info_attribute.html#a84b69e11a7e788457a671f09ec5b4df6", null ]
];