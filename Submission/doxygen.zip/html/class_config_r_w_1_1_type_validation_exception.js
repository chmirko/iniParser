var class_config_r_w_1_1_type_validation_exception =
[
    [ "TypeValidationException", "class_config_r_w_1_1_type_validation_exception.html#a714d8cab410c9b018973febb965bd9ca", null ],
    [ "ValidatedType", "class_config_r_w_1_1_type_validation_exception.html#a1d2ec702bb88c94180cedab993207ae4", null ]
];