var namespaces =
[
    [ "ConfigRW", "namespace_config_r_w.html", "namespace_config_r_w" ]
];