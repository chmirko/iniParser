var interface_usage_examples_1_1_player =
[
    [ "Name", "interface_usage_examples_1_1_player.html#ad723bbb4f5d12ddddb98de9b4a869604", null ],
    [ "SavedLevel", "interface_usage_examples_1_1_player.html#a4860c2a20019f223622deff7a49d7b4c", null ]
];