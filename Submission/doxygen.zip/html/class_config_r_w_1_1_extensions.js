var class_config_r_w_1_1_extensions =
[
    [ "Last< T >", "class_config_r_w_1_1_extensions.html#a79e824a9a422601fd2e366c32447965e", null ]
];