var class_config_r_w_1_1_parsing_1_1_int64_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_int64_converter.html#a6238bd54427aadef132b5479088c167c", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_int64_converter.html#afa6b255b787546dcc4c35102662a633e", null ]
];