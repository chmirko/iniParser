var class_config_r_w_1_1_parsing_1_1_u_int64_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_u_int64_converter.html#af59e3e9e709842f99e692f6f8cc7044f", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_u_int64_converter.html#aae3b2beb8bff0ffdec7b57dc1612b22c", null ]
];