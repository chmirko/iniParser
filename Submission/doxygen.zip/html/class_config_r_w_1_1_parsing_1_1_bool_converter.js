var class_config_r_w_1_1_parsing_1_1_bool_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_bool_converter.html#a172284713f236a2e0b7c4f2c2f3a3177", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_bool_converter.html#a56ef940c29865a4438ae15031327535f", null ]
];