var interface_config_r_w_1_1_i_configuration =
[
    [ "SaveTo", "interface_config_r_w_1_1_i_configuration.html#ac168b64edf20fef684759abf16856462", null ],
    [ "SetComment", "interface_config_r_w_1_1_i_configuration.html#a9284e4876dcc103fd864cd77e9c74fd5", null ],
    [ "WriteTo", "interface_config_r_w_1_1_i_configuration.html#a40d819b4af003922c9893c38d9d04511", null ]
];