var class_config_r_w_1_1_parsing_1_1_u_int32_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_u_int32_converter.html#ad724a3917cfae9f03063717cb4eafe86", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_u_int32_converter.html#a5d127f4fa0e8eed2f2e7d0915b2fc52e", null ]
];