var dir_ddd42bccb3df40778a2054ed93757952 =
[
    [ "Properties", "dir_4e119de44f173c2a72a496ccfcd3fc33.html", "dir_4e119de44f173c2a72a496ccfcd3fc33" ],
    [ "DocumentationExamples.cs", "_documentation_examples_8cs.html", [
      [ "Players", "interface_usage_examples_1_1_players.html", "interface_usage_examples_1_1_players" ],
      [ "Player", "interface_usage_examples_1_1_player.html", "interface_usage_examples_1_1_player" ],
      [ "Examples", "class_usage_examples_1_1_examples.html", "class_usage_examples_1_1_examples" ],
      [ "ConfigBuilder", "class_usage_examples_1_1_config_builder.html", "class_usage_examples_1_1_config_builder" ],
      [ "OptionBuilder", "class_usage_examples_1_1_option_builder.html", "class_usage_examples_1_1_option_builder" ],
      [ "Config", "class_usage_examples_1_1_config.html", "class_usage_examples_1_1_config" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ]
];