var interface_usage_examples_1_1_special_type_section =
[
    [ "Array", "interface_usage_examples_1_1_special_type_section.html#ac6665138d70321b9fee7f0c3cbdc1fee", null ],
    [ "Enum", "interface_usage_examples_1_1_special_type_section.html#aabcd2acdc8e58190e7a7e614eafb9b03", null ],
    [ "Enumerable", "interface_usage_examples_1_1_special_type_section.html#a7d8d4ad2d7c5e3b5e1392888c8e8113a", null ],
    [ "EnumSet", "interface_usage_examples_1_1_special_type_section.html#ae81d6a170a7643002a25e2cebf1db9c0", null ],
    [ "List", "interface_usage_examples_1_1_special_type_section.html#aa9f2ba9698d8a84399219d3c470c51ca", null ]
];