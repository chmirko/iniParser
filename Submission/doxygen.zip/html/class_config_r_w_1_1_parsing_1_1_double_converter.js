var class_config_r_w_1_1_parsing_1_1_double_converter =
[
    [ "Deserialize", "class_config_r_w_1_1_parsing_1_1_double_converter.html#a865665cd5091d26351056687f6e7de5e", null ],
    [ "Serialize", "class_config_r_w_1_1_parsing_1_1_double_converter.html#a0e3bad8ff05470252c5bd887b7bc34e8", null ]
];