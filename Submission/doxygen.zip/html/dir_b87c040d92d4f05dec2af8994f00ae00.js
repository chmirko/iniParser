var dir_b87c040d92d4f05dec2af8994f00ae00 =
[
    [ "ConfigCreation", "dir_ffb1adca6bd06254a01a47064e4121de.html", "dir_ffb1adca6bd06254a01a47064e4121de" ],
    [ "Parsing", "dir_f24c83a4c773870a9f8182e7247aa2d4.html", "dir_f24c83a4c773870a9f8182e7247aa2d4" ],
    [ "Properties", "dir_adc12c7c8d8ddc7d3926f64abab0a5bb.html", "dir_adc12c7c8d8ddc7d3926f64abab0a5bb" ],
    [ "Attributes.cs", "_attributes_8cs.html", [
      [ "SectionInfoAttribute", "class_config_r_w_1_1_section_info_attribute.html", "class_config_r_w_1_1_section_info_attribute" ],
      [ "OptionInfoAttribute", "class_config_r_w_1_1_option_info_attribute.html", "class_config_r_w_1_1_option_info_attribute" ],
      [ "DefaultCommentAttribute", "class_config_r_w_1_1_default_comment_attribute.html", "class_config_r_w_1_1_default_comment_attribute" ],
      [ "RangeAttribute", "class_config_r_w_1_1_range_attribute.html", "class_config_r_w_1_1_range_attribute" ]
    ] ],
    [ "ConfigRWException.cs", "_config_r_w_exception_8cs.html", [
      [ "ConfigRWException", "class_config_r_w_1_1_config_r_w_exception.html", "class_config_r_w_1_1_config_r_w_exception" ]
    ] ],
    [ "Configuration.cs", "_configuration_8cs.html", "_configuration_8cs" ],
    [ "Documentation.cs", "_documentation_8cs.html", null ],
    [ "IConfiguration.cs", "_i_configuration_8cs.html", [
      [ "IConfiguration", "interface_config_r_w_1_1_i_configuration.html", "interface_config_r_w_1_1_i_configuration" ]
    ] ],
    [ "NET_3.5_fix.cs", "_n_e_t__3_85__fix_8cs.html", [
      [ "Extensions", "class_config_r_w_1_1_extensions.html", "class_config_r_w_1_1_extensions" ],
      [ "Tuple< T1, T2 >", "class_config_r_w_1_1_tuple_3_01_t1_00_01_t2_01_4.html", "class_config_r_w_1_1_tuple_3_01_t1_00_01_t2_01_4" ]
    ] ],
    [ "QualifiedName.cs", "_qualified_name_8cs.html", [
      [ "QualifiedName", "class_config_r_w_1_1_qualified_name.html", "class_config_r_w_1_1_qualified_name" ]
    ] ]
];