var class_config_r_w_1_1_default_comment_attribute =
[
    [ "DefaultCommentAttribute", "class_config_r_w_1_1_default_comment_attribute.html#a7b0457797121751c947b6e4a7a4fd70b", null ],
    [ "DefaultCommentAttribute", "class_config_r_w_1_1_default_comment_attribute.html#af069c4cb4531592014e25ba55f608b9d", null ],
    [ "CommentText", "class_config_r_w_1_1_default_comment_attribute.html#a7e44639f765c77d30eb5598b83a6630c", null ]
];