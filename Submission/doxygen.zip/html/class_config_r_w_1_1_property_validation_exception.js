var class_config_r_w_1_1_property_validation_exception =
[
    [ "PropertyValidationException", "class_config_r_w_1_1_property_validation_exception.html#a0f52570f5194488f9603dcaa64115467", null ],
    [ "ValidatedProperty", "class_config_r_w_1_1_property_validation_exception.html#a2f1895c6270ac7f58f2fddaf5facf89a", null ]
];