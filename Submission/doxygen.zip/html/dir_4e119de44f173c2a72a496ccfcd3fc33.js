var dir_4e119de44f173c2a72a496ccfcd3fc33 =
[
    [ "AssemblyInfo.cs", "_usage_examples_2_properties_2_assembly_info_8cs.html", null ]
];