var searchData=
[
  ['strict',['Strict',['../namespace_config_r_w.html#ad7a7c48e02463927bbb71dab3941c03aa2e979835dd62324f5bfe217449ba4974',1,'ConfigRW']]]
];
