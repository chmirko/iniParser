var searchData=
[
  ['name',['Name',['../class_config_r_w_1_1_config_creation_1_1_config_section.html#a9b26061449d4959c9cb06bb5b2dec620',1,'ConfigRW::ConfigCreation::ConfigSection']]]
];
