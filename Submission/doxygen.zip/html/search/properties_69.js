var searchData=
[
  ['id',['ID',['../class_config_r_w_1_1_section_info_attribute.html#af54d01b2077eeaf241f061157e65feb5',1,'ConfigRW.SectionInfoAttribute.ID()'],['../class_config_r_w_1_1_option_info_attribute.html#adc9a8a972c820809a4c681f429242497',1,'ConfigRW.OptionInfoAttribute.ID()']]],
  ['isoptional',['IsOptional',['../class_config_r_w_1_1_section_info_attribute.html#a84b69e11a7e788457a671f09ec5b4df6',1,'ConfigRW.SectionInfoAttribute.IsOptional()'],['../class_config_r_w_1_1_option_info_attribute.html#a28f099192b19a33b7452c08cfa0441be',1,'ConfigRW.OptionInfoAttribute.IsOptional()']]]
];
