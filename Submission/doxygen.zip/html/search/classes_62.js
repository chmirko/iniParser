var searchData=
[
  ['boolconverter',['BoolConverter',['../class_config_r_w_1_1_parsing_1_1_bool_converter.html',1,'ConfigRW::Parsing']]]
];
