var searchData=
[
  ['knownsections',['knownSections',['../class_config_r_w_1_1_parsing_1_1_config_parser.html#a1b7bdb81932f1212f68774a3d3e1c068',1,'ConfigRW.Parsing.ConfigParser.knownSections()'],['../class_config_r_w_1_1_parsing_1_1_lexer.html#a20816414afa5c5b8bdad2b19d6551994',1,'ConfigRW.Parsing.Lexer.knownSections()']]]
];
